using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class LevelBlockData
{
    public ShapeType shapeType;
    public MoveDirection moveDirection;
    public Vector2Int gridPosition;

    [Tooltip("Local cells relative to gridPosition. Empty means a single cell at (0,0) using Shape Type.")]
    public List<ShapeCellData> cells = new List<ShapeCellData>();

    [Tooltip("Simple = cells only. ShapeInShape also requires Outer Shape to match.")]
    public PieceComposition composition = PieceComposition.Simple;

    [Tooltip("Outer identity for ShapeInShape. Ignored for Simple pieces.")]
    public ShapeType outerShape = ShapeType.Square;

    [Tooltip("Reserved for future rotation. 0 = authored orientation. Not applied at runtime.")]
    public int orientationSteps;

    [Tooltip("When enabled, this complete block structure starts frozen with the configured durability.")]
    public bool hasIce;

    [Min(1)]
    [Tooltip("Successful match events required to break this structure's ice.")]
    public int iceDurability = 1;

    public LevelBlockData Clone()
    {
        return new LevelBlockData
        {
            shapeType = shapeType,
            moveDirection = moveDirection,
            gridPosition = gridPosition,
            cells = ShapeLayout.Clone(cells, shapeType),
            composition = composition,
            outerShape = outerShape,
            orientationSteps = orientationSteps,
            hasIce = hasIce,
            iceDurability = iceDurability
        };
    }
}
